# ALFRED

ALFRED is a compact ESP32-CAM assistive-intelligence prototype with a browser dashboard. The device serves one responsive UI to phones, tablets and computers; Gemini requests and long-term memory can use an optional authenticated Supabase backend.

## Project map

- `backups/AlfredsFirmware_v2.2_original_2026-11-07.ino` — untouched local-only source backup.
- A redacted source copy is included for review; the original is excluded from GitHub because it contains a shared recovery-network password.
- `firmware/AlfredsFirmware_v2.2/AlfredsFirmware_v2.2.ino` — working copy for firmware updates.
- `android/` — existing Android WebView companion source.
- `backend/supabase/` — Edge Function and SQL migration for authenticated cloud AI and memory.
- `docs/` — setup, hardware scope, security, status and verification checklist.

## Verification status

The current firmware compiled for AI Thinker ESP32-CAM with ESP32 Arduino core 3.3.10 and was flashed through the CP2102 adapter on 2026-11-07; esptool verified the written flash data. Camera, Wi-Fi, speech, and sensor behavior still requires a normal-boot hardware check after disconnecting GPIO0 from GND and pressing RST/EN.

## Quick behavior

1. The ESP32 tries its saved Wi-Fi network on boot. If it cannot connect, it starts `ALFRED-Setup`; join it from any phone or computer and open `http://192.168.4.1/` to configure Wi-Fi.
2. Once joined to Wi-Fi, open the address shown by the device in any modern browser. The Android wrapper is optional.
3. For local Gemini mode, enter your own Gemini API key in Settings. It is kept in that browser profile if you enable “Remember on this browser.”
4. For shared AI access and durable cross-device memory, deploy the optional Supabase backend, create an account in its cloud settings in ALFRED, and configure the Gemini key(s) as Supabase secrets. The firmware contains no provider key.

## Safety and privacy

ALFRED is supplementary information for people who are blind or have low vision. It is not a navigation aid or substitute for a white cane, guide dog, or other established mobility aid. The flame sensor is not a fire alarm. The ESP32 dashboard is currently unauthenticated on the local network; use a trusted Wi-Fi network. Cloud memory is private to the signed-in Supabase user when the migration and function are deployed as documented. Camera images are sent only with vision requests.
