# Setup and deployment

## ESP32-CAM

1. Open `firmware/AlfredsFirmware_v2.2/AlfredsFirmware_v2.2.ino` with Arduino IDE. Select **AI Thinker ESP32-CAM**, enable PSRAM, and use the ESP32 Arduino core noted in the sketch header/audit.
2. The current sketch compiled and its flash write was verified on 2026-11-07. For future uploads, connect GPIO0 to GND while uploading. After the upload finishes, remove the GPIO0-to-GND jumper and press RST/EN once so the sketch starts normally. If GPIO0 remains grounded, the board stays in programming mode instead of running ALFRED.
3. On first boot, join Wi-Fi `ALFRED-Setup` (the setup password is unique to this board and is printed to Serial Monitor only when recovery AP starts) and visit `http://192.168.4.1/`.
4. In Network, scan/select the 2.4 GHz Wi-Fi, enter its password, and save. After ALFRED connects, open `http://alfred.local/` where mDNS is supported, or use the DHCP IP shown on screen. The setup page is plain HTTP on the local network, so only provision on a network you trust.
5. Open the dashboard URL in a current phone/tablet/desktop browser. Keep ALFRED and the phone/computer on the same network. Browser speech recognition depends on browser and OS support; typed requests and spoken replies are the fallback paths.

The AP setup password, sensor wiring, ESP32 strapping pins, brownout behavior and camera flow need physical validation before a public demonstration. In particular, HC-SR04 Echo is 5 V and must be divided to ESP32-safe voltage. A successful flash does not verify camera, Wi-Fi, speech or sensor operation.

## Optional cloud assistant and cross-device memory (Supabase)

Supabase keeps provider keys server-side and stores per-account conversation history and explicitly saved facts. Use a separate project for the competition demo, enable email/password auth, and set sensible project spending/rate limits.

1. Install the Supabase CLI and authenticate it. From `backend/`, initialize/link a Supabase project using the project reference from its dashboard.
2. Apply `supabase/migrations/202611070001_alfred_memory.sql` to the project.
3. In Supabase Edge Function secrets, set `GEMINI_API_KEYS` to a comma- or newline-separated list of provider keys. Add keys in priority order. Keys belong in Supabase secrets, never in Git, firmware or an APK. Optionally test without a server key by entering a personal Gemini key in each browser's Settings.
4. Deploy the `alfred-assistant` function.
5. In the ALFRED Settings page on each phone or computer, enter the project URL and publishable/anon key. Create/sign in to the same account and use cloud memory. Do not use an admin/service-role key in the browser.
6. Say “Remember that …” to save a durable fact. “Review saved memories” shows saved facts; “Clear cloud history & memory” deletes this user's conversations and memories.

The function authenticates every request against Supabase Auth and scopes all database reads/writes to that verified user ID. The migration intentionally gives no direct table access to browser roles. Do not disable these safeguards. Conversation text is saved to cloud for cross-device continuity; images are not saved, though a camera image attached to a request is sent to Gemini during that request. Users can clear stored history and facts in Settings.

## API key rotation

Server keys are tried first. On provider key rejection, permission errors or quota/rate-limit responses, the Edge Function tries the next configured key. It stops on request/model errors that a new key cannot fix. A single key cannot bypass a quota shared by its Google project. The per-account cloud limit still applies when using your own key; sign out and use local mode for requests that should not use ALFRED cloud services. Use keys from separately managed projects only when those projects and billing limits are legitimate and controlled by the project owner.

## GitHub

This local project is initialized as a Git repository. Before pushing, create/select a private repository, set its remote, review staged files and verify no credentials, account exports, build outputs or personal hardware photos are included. Only the versioned source and documentation are appropriate for the repository. This checkout currently has no GitHub remote configured.
