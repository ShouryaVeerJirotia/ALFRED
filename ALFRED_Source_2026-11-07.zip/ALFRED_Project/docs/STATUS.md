# ALFRED status (2026-11-07)

## Existing in the v2.2 sketch (source-level only)

- Responsive single-page dashboard served by ESP32-CAM.
- Camera snapshot/vision request, sensor telemetry, voice input/output, and phone-action intents.
- Wi-Fi saved-network recovery access point and web provisioning.
- Browser-side user Gemini keys and rotation logic.
- Confirmation flow for call/SMS intents.

These have not all been built or exercised on hardware in this project checkout yet.

## Added in this project

- A versioned project copy, original local firmware backup, and Android source. The original backup is intentionally excluded from GitHub; its redacted review copy is available under `backups/`.
- A unique per-board recovery AP password and `alfred.local` mDNS alias when the network supports it.
- A Supabase account UI, user-specific cloud chat history, explicitly saved facts, clear-memory action, and daily request limit in the Edge Function source.
- Optional authenticated cloud AI proxy and per-user persistent conversation/memory support (deployment/configuration still required).

## Not yet implemented or verified

OCR/read-aloud, barcode/QR reader, Hindi speech selection, trusted-contact SOS/location share, universal testing across browser/device families, memory deployment and real account flows, and hardware sensor validation.

No feature should be described as working until its checklist is completed. This prototype is not a navigation replacement.
