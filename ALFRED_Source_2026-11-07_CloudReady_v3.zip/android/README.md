# Alfred Android Wrapper

This is a native Android WebView wrapper for the ESP32 Alfred dashboard.

## Build in Android Studio

1. Open this folder in Android Studio:
   `/Users/raviraijirotia/Documents/Codex/2026-06-23/hi/outputs/AlfredAndroidWrapper`
2. Let Gradle sync.
3. Build or run the `app` configuration.
4. In the app, enter the ESP32 URL printed by Arduino Serial Monitor, for example:
   `http://192.168.1.45/`

The firmware dashboard now detects `window.AlfredAndroid` and uses native Android calls for Spotify, Google Maps, calls, SMS, and alarms.
