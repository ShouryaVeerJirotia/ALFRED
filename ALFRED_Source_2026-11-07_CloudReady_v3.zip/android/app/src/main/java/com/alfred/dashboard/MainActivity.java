package com.alfred.dashboard;

import android.Manifest;
import android.app.Activity;
import android.app.SearchManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int REQUEST_RUNTIME_PERMS = 44;
    private static final String PREFS = "alfred_prefs";
    private static final String PREF_DASHBOARD_URL = "dashboard_url";
    private static final String OLD_DEFAULT_URL = "http://192.168.1.100/";
    private static final String DEFAULT_URL = "http://alfred.local/";

    private WebView webView;
    private EditText urlField;
    private SharedPreferences prefs;
    private TextToSpeech textToSpeech;
    private String dashboardHost = "";
    private boolean textToSpeechReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();
        configureWebView();
        textToSpeech = new TextToSpeech(this, this);
        requestNeededPermissions();
        String savedUrl = prefs.getString(PREF_DASHBOARD_URL, DEFAULT_URL);
        if (OLD_DEFAULT_URL.equals(savedUrl) || "http://192.168.1.13/".equals(savedUrl)) {
            savedUrl = DEFAULT_URL;
        }
        loadDashboard(savedUrl);
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            int result = textToSpeech.setLanguage(Locale.UK);
            textToSpeechReady = result != TextToSpeech.LANG_MISSING_DATA
                    && result != TextToSpeech.LANG_NOT_SUPPORTED;
            textToSpeech.setSpeechRate(0.95f);
            textToSpeech.setPitch(0.82f);
        }
    }

    @Override
    protected void onDestroy() {
        if (textToSpeech != null) {
            textToSpeech.stop();
            textToSpeech.shutdown();
        }
        super.onDestroy();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xff07101d);

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setPadding(12, 12, 12, 10);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setBackgroundColor(0xff07101d);

        urlField = new EditText(this);
        urlField.setSingleLine(true);
        urlField.setTextColor(0xffffffff);
        urlField.setHintTextColor(0xff80dff2);
        urlField.setTextSize(13);
        urlField.setHint("ESP32 URL, e.g. http://192.168.1.13/");
        urlField.setBackgroundColor(0xff111827);
        toolbar.addView(urlField, new LinearLayout.LayoutParams(0, 96, 1));

        Button loadButton = new Button(this);
        loadButton.setText("LOAD");
        loadButton.setTextSize(12);
        toolbar.addView(loadButton, new LinearLayout.LayoutParams(150, 96));
        loadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadDashboard(urlField.getText().toString());
            }
        });

        webView = new WebView(this);
        root.addView(toolbar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1));

        TextView offlineHint = new TextView(this);
        offlineHint.setText("Set this to the ESP32 IP printed in Arduino Serial Monitor.");
        offlineHint.setTextColor(0xffa5f3fc);
        offlineHint.setTextSize(11);
        offlineHint.setPadding(12, 6, 12, 12);
        root.addView(offlineHint);

        setContentView(root);
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setDatabaseEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webView.addJavascriptInterface(new AlfredBridge(), "AlfredAndroid");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP
                        && request.getOrigin() != null
                        && isDashboardOrigin(request.getOrigin())) {
                    String[] resources = request.getResources();
                    for (String resource : resources) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                            request.grant(new String[] { PermissionRequest.RESOURCE_AUDIO_CAPTURE });
                            return;
                        }
                    }
                }
                request.deny();
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleExternalUri(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleExternalUri(Uri.parse(url));
            }
        });
    }

    private void loadDashboard(String rawUrl) {
        String normalized = normalizeUrl(rawUrl);
        if (normalized.isEmpty()) {
            showToast("Enter ALFRED's local IP address or alfred.local.");
            return;
        }
        Uri uri = Uri.parse(normalized);
        dashboardHost = uri.getHost();
        urlField.setText(normalized);
        prefs.edit().putString(PREF_DASHBOARD_URL, normalized).apply();
        webView.loadUrl(normalized);
    }

    private String normalizeUrl(String rawUrl) {
        String value = rawUrl == null ? "" : rawUrl.trim();
        if (value.isEmpty()) value = DEFAULT_URL;
        if (!value.startsWith("http://") && !value.startsWith("https://")) value = "http://" + value;
        try {
            Uri uri = Uri.parse(value);
            String host = uri.getHost();
            if (host == null || !("http".equalsIgnoreCase(uri.getScheme())
                    || "https".equalsIgnoreCase(uri.getScheme())) || !isAllowedDeviceHost(host)) return "";
            return uri.toString();
        } catch (Exception ex) {
            return "";
        }
    }

    private boolean isDashboardOrigin(Uri uri) {
        if (uri == null || webView == null || webView.getUrl() == null) return false;
        Uri current = Uri.parse(webView.getUrl());
        int currentPort = current.getPort() >= 0 ? current.getPort() : ("https".equalsIgnoreCase(current.getScheme()) ? 443 : 80);
        int targetPort = uri.getPort() >= 0 ? uri.getPort() : ("https".equalsIgnoreCase(uri.getScheme()) ? 443 : 80);
        return current.getScheme() != null && current.getScheme().equalsIgnoreCase(uri.getScheme())
                && current.getHost() != null && current.getHost().equalsIgnoreCase(uri.getHost())
                && currentPort == targetPort;
    }

    private boolean isAllowedDeviceHost(String host) {
        String h = host.toLowerCase(Locale.ROOT);
        if ("localhost".equals(h) || h.endsWith(".local")) return true;
        String[] parts = h.split("\\.");
        if (parts.length != 4) return false;
        try {
            int a = Integer.parseInt(parts[0]), b = Integer.parseInt(parts[1]);
            int c = Integer.parseInt(parts[2]), d = Integer.parseInt(parts[3]);
            if (a < 0 || a > 255 || b < 0 || b > 255 || c < 0 || c > 255 || d < 0 || d > 255) return false;
            return a == 10 || a == 127 || (a == 192 && b == 168)
                    || (a == 172 && b >= 16 && b <= 31) || (a == 169 && b == 254);
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    private boolean handleExternalUri(Uri uri) {
        String scheme = uri.getScheme();
        if (scheme == null) return true;
        if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            if (isDashboardOrigin(uri)) return false;
            startExternal(new Intent(Intent.ACTION_VIEW, uri), "No browser can open this link.");
            return true;
        }

        if ("spotify".equals(scheme)) {
            String spotifyUri = uri.toString();
            if (spotifyUri.startsWith("spotify:search:")) {
                launchSpotify(spotifyUri.substring("spotify:search:".length()));
            } else {
                startExternal(new Intent(Intent.ACTION_VIEW, uri).setPackage("com.spotify.music"), "Spotify is not installed.");
            }
            return true;
        }

        if ("google.navigation".equals(scheme) || "geo".equals(scheme)) {
            startExternal(new Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.apps.maps"), "Google Maps is not installed.");
            return true;
        }

        if ("tel".equals(scheme) || "sms".equals(scheme) || "smsto".equals(scheme)) {
            startExternal(new Intent(Intent.ACTION_VIEW, uri), "No app can handle this request.");
            return true;
        }

        if ("intent".equals(scheme)) {
            try {
                Intent intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                String packageName = intent.getPackage();
                String query = intent.getStringExtra(SearchManager.QUERY);
                if (query == null) {
                    query = intent.getStringExtra("query");
                }
                if ("com.spotify.music".equals(packageName)) {
                    launchSpotify(query == null ? "" : query);
                } else if ("com.google.android.apps.maps".equals(packageName)) {
                    startExternal(intent, "Google Maps is not installed.");
                } else {
                    startExternal(intent, "No app can handle this request.");
                }
            } catch (Exception ex) {
                showToast("Intent failed: " + ex.getMessage());
            }
            return true;
        }

        return false;
    }

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return;
        }
        requestPermissions(new String[] {
                Manifest.permission.RECORD_AUDIO
        }, REQUEST_RUNTIME_PERMS);
    }

    private void startExternal(final Intent intent, final String missingMessage) {
        startExternal(intent, missingMessage, null);
    }

    private void startExternal(final Intent intent, final String missingMessage, final Runnable fallback) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    startActivity(intent);
                } catch (ActivityNotFoundException ex) {
                    if (fallback != null) {
                        fallback.run();
                    } else {
                        Toast.makeText(MainActivity.this, missingMessage, Toast.LENGTH_LONG).show();
                    }
                } catch (SecurityException ex) {
                    Toast.makeText(MainActivity.this, "Permission needed for that action.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void showToast(final String text) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, text, Toast.LENGTH_LONG).show();
            }
        });
    }

    private String encode(String value) {
        return URLEncoder.encode(value == null ? "" : value.trim(), StandardCharsets.UTF_8).replace("+", "%20");
    }

    private void launchSpotify(String query) {
        if (query == null || query.trim().isEmpty()) {
            showToast("Enter a track first.");
            return;
        }

        Intent mediaSearch = new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
        mediaSearch.setPackage("com.spotify.music");
        mediaSearch.putExtra(SearchManager.QUERY, query.trim());
        mediaSearch.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/audio");

        final Intent spotifySearch = new Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:" + encode(query)));
        spotifySearch.setPackage("com.spotify.music");
        startExternal(mediaSearch, "Spotify is not installed.", new Runnable() {
            @Override
            public void run() {
                startExternal(spotifySearch, "Spotify is not installed.");
            }
        });
        nudgeSpotifyPlayback();
    }

    private void nudgeSpotifyPlayback() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                webView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                        if (audioManager == null) {
                            return;
                        }
                        long now = System.currentTimeMillis();
                        KeyEvent down = new KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY, 0);
                        KeyEvent up = new KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY, 0);
                        audioManager.dispatchMediaKeyEvent(down);
                        audioManager.dispatchMediaKeyEvent(up);
                    }
                }, 2600);
            }
        });
    }

    private void launchNavigation(String destination) {
        if (destination == null || destination.trim().isEmpty()) {
            showToast("Enter a destination first.");
            return;
        }
        Uri uri = Uri.parse("google.navigation:q=" + encode(destination) + "&mode=d");
        Intent navIntent = new Intent(Intent.ACTION_VIEW, uri);
        navIntent.setPackage("com.google.android.apps.maps");
        startExternal(navIntent, "Google Maps is not installed.");
    }

    public class AlfredBridge {
        @JavascriptInterface
        public void playSpotify(String query) {
            launchSpotify(query);
        }

        @JavascriptInterface
        public void navigate(String destination) {
            launchNavigation(destination);
        }

        @JavascriptInterface
        public void callNumber(String phone) {
            if (phone == null || phone.trim().isEmpty()) {
                showToast("Enter a phone number first.");
                return;
            }
            Intent callIntent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(phone.trim())));
            startExternal(callIntent, "No dialer app is available.");
        }

        @JavascriptInterface
        public void sendSms(String phone, String body) {
            if (phone == null || phone.trim().isEmpty()) {
                showToast("Enter a phone number first.");
                return;
            }
            Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(phone.trim())));
            smsIntent.putExtra("sms_body", body == null ? "" : body);
            startExternal(smsIntent, "No SMS app is available.");
        }

        @JavascriptInterface
        public void setAlarm(String label, int hour, int minute) {
            Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, label == null ? "Alfred alarm" : label)
                    .putExtra(AlarmClock.EXTRA_HOUR, Math.max(0, Math.min(23, hour)))
                    .putExtra(AlarmClock.EXTRA_MINUTES, Math.max(0, Math.min(59, minute)));
            startExternal(alarmIntent, "No alarm app is available.");
        }

        @JavascriptInterface
        public void speak(final String text) {
            if (text == null || text.trim().isEmpty()) {
                return;
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (textToSpeechReady && textToSpeech != null) {
                        textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "alfred-speech");
                    } else {
                        Toast.makeText(MainActivity.this, text, Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public boolean isNativeReady() {
            return true;
        }

        @JavascriptInterface
        public String networkStatus() {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) {
                return "unknown";
            }
            Network network = cm.getActiveNetwork();
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            if (caps == null) {
                return "offline";
            }
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                return "wifi";
            }
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                return "cellular";
            }
            return "online";
        }
    }
}
