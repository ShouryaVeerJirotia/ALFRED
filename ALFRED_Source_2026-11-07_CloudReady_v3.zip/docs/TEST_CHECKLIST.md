# ALFRED verification checklist

## Firmware build and flash

- [x] Compile with AI Thinker ESP32-CAM target and ESP32 Arduino core 3.3.10.
- [x] Flash latest firmware through CP2102; esptool verified the written image.
- [ ] Remove GPIO0-to-GND and press reset; confirm normal boot logs, camera startup and dashboard availability.
- [ ] Test power cycling, lost router, wrong password, setup AP and successful new Wi-Fi save.

## Browser/device support

- [ ] Android Chrome; iPhone/iPad Safari; Windows Chrome/Edge; macOS Safari/Chrome.
- [ ] Responsive layout, screen reader labels, keyboard operation, camera fetch and sensor data.
- [ ] Typed request and TTS on every target; microphone recognition only where target browser supports it.
- [ ] Android wrapper bridge actions and runtime permissions.

## Product functions

- [x] Supabase memory/quota migration and `alfred-assistant` Edge Function deployed; `GEMINI_API_KEYS` configured as a Supabase secret.
- [ ] Signed-in Gemini chat, search grounding, image description and key rotation for an exhausted key.
- [ ] Invalid key/model/network errors are shown accurately and do not loop.
- [ ] Supabase sign-up/sign-in, session refresh, cross-device chat history, explicit memory, review and delete.
- [ ] Always-on voice limits, wake phrase, Hindi/English interaction and device-by-device behavior.
- [ ] Reminder creation, persistence, notification delivery, quiet hours and cancellation.
- [ ] Codex bridge pairing, workspace limits, proposed diff, explicit approval and safe failure behavior.
- [ ] Phone action intents: call/SMS always require confirmation; test music/navigation links.
- [ ] Camera absent, sensor absent/stale and no-network states remain understandable.

## Physical and accessibility validation

- [ ] Stable power under camera/Wi-Fi load; camera ribbon secure; no brownout/reboot.
- [ ] HC-SR04 Echo voltage divided to 3.3 V; check boot-strapping-pin effects on GPIO12/15.
- [ ] Sensor measurements compared to known references; flame sensor tested only as a hobby sensor.
- [ ] Blind/low-vision user review of setup, voice feedback, screen reader flow, errors and confirmations.
- [ ] Clearly state that ALFRED is supplementary and cannot guarantee safe navigation.
