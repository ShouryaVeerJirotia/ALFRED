# ALFRED

ALFRED is a compact ESP32-CAM assistive-intelligence prototype with a browser dashboard. The device serves one responsive UI to phones, tablets and computers; the ALFRED-Showcase Supabase backend provides authenticated chat history and long-term memory across devices.

The complete source, backend, Android companion, setup notes and assistant roadmap are in the [cloud-ready source package](https://github.com/ShouryaVeerJirotia/ALFRED/blob/main/ALFRED_Source_2026-11-08_release1.zip). The standalone latest firmware file is also available at the repository root as `ALFRED_Firmware_2026-11-08.ino`.

## Project map

- `backups/AlfredsFirmware_v2.2_original_2026-11-07.ino` — untouched local-only source backup.
- A redacted source copy is included for review; the original is excluded from GitHub because it contains a shared recovery-network password.
- `firmware/AlfredsFirmware_v2.2/AlfredsFirmware_v2.2.ino` — working copy for firmware updates.
- `android/` — existing Android WebView companion source.
- `backend/supabase/` — Edge Function and SQL migration for authenticated cloud AI and memory.
- `desktop/` — localhost dashboard proxy and approval-gated Codex code-edit companion.
- `docs/` — setup, hardware scope, status, verification checklist and Jarvis roadmap.

## Verification status

The previous firmware revision, including bilingual voice selection and safer API-key persistence defaults, compiled for AI Thinker ESP32-CAM with ESP32 Arduino core 3.3.10 and was flash-verified through the CP2102 on 2026-11-07. The newer natural-voice, search, and Codex companion UI changes are local and have not been flashed. Normal-boot camera, Wi-Fi, speech, and sensor behavior still needs hardware verification.

## Quick behavior

1. The ESP32 tries its saved Wi-Fi network on boot. If it cannot connect, it starts `ALFRED-Setup`; join it from any phone or computer and open `http://192.168.4.1/` to configure Wi-Fi.
2. Once joined to Wi-Fi, open the address shown by the device in any modern browser. The Android wrapper is optional.
3. To use a personal Gemini key, enter it in Settings. By default it stays in page memory; enabling “Keep keys in this browser” saves it in that browser profile’s local storage without encryption.
4. In Settings, create or sign in to an ALFRED cloud account. The Supabase project details are prefilled, and a rotating shared Gemini key pool is configured server-side. You can also enter your own Gemini keys; the firmware contains no Gemini provider key.
5. In Settings → Behaviour, choose Hindi, English (India), or automatic Hindi/English selection. Tap the mic and speak naturally; a wake phrase is optional while listening is active. Tap it again to stop. Browser listening depends on browser support and does not continue reliably with the page backgrounded or the phone locked.
6. To use Codex for project edits on a computer, install and sign in to Codex CLI, then run `python3 desktop/alfred_desktop.py --device-url http://alfred.local --workspace /absolute/path/to/your/project` from this repository. If `alfred.local` does not resolve, use ALFRED's current private Wi-Fi IP. Open `http://127.0.0.1:8765` in that computer's browser. A coding request is confirmed before Codex starts; Codex works in an isolated copy, and ALFRED displays a patch for your separate approval before applying it. This first bridge only edits the selected Git project; it does not control other desktop apps or deploy code.

## Safety and privacy

ALFRED is supplementary information for people who are blind or have low vision. It is not a navigation aid or substitute for a white cane, guide dog, or other established mobility aid. The flame sensor is not a fire alarm. The ESP32 dashboard is currently unauthenticated on the local network; use a trusted Wi-Fi network. Cloud memory is private to the signed-in Supabase user. Camera images are sent only with vision requests.

The desktop companion binds only to `127.0.0.1` and proxies ALFRED's local dashboard, which also gives desktop browsers a `localhost` page for microphone access. A computer must run the companion itself; the ESP32 never accepts arbitrary computer commands. Gemini Search grounding is enabled by default for current-information prompts in new browser profiles and can be switched off in Settings. Google's current Gemini API pricing page lists it as unavailable on the Free tier; paid-tier eligibility and charges vary by model.
