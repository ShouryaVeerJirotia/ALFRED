import { createClient } from 'npm:@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, apikey, content-type, x-client-info',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Max-Age': '86400',
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...cors, 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
});
const env = (name: string) => Deno.env.get(name) ?? '';
function parseKeySet(name: string): Record<string, string> {
  try { return JSON.parse(env(name) || '{}'); } catch { return {}; }
}
function uniqueKeys(input: unknown): string[] {
  if (!Array.isArray(input)) return [];
  return [...new Set(input.filter((x): x is string => typeof x === 'string')
    .map(x => x.trim()).filter(x => x.length >= 20 && x.length <= 200))].slice(0, 8);
}
function userText(contents: any[]): string {
  return contents.filter(x => x?.role === 'user').flatMap(x => x.parts ?? [])
    .map((p: any) => typeof p?.text === 'string' ? p.text : '')
    .filter(Boolean).join('\n').slice(0, 4000);
}
function textFromGemini(data: any): string {
  const candidate = data?.candidates?.[0];
  const parts = candidate?.content?.parts ?? [];
  return parts.map((p: any) => typeof p?.text === 'string' ? p.text : '').join('').trim();
}
function sourcesFromGemini(data: any): Array<{ title: string; url: string }> {
  const chunks = data?.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
  const seen = new Set<string>();
  const sources: Array<{ title: string; url: string }> = [];
  for (const chunk of chunks) {
    const web = chunk?.web;
    if (typeof web?.uri !== 'string') continue;
    try {
      const url = new URL(web.uri);
      if (url.protocol !== 'https:' || seen.has(url.href)) continue;
      seen.add(url.href);
      sources.push({ title: String(web.title || url.hostname).slice(0, 160), url: url.href });
    } catch { /* Ignore malformed provider citations. */ }
    if (sources.length >= 5) break;
  }
  return sources;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ error: 'Use POST.' }, 405);

  const url = env('SUPABASE_URL');
  const publishables = parseKeySet('SUPABASE_PUBLISHABLE_KEYS');
  const anonKey = publishables.default || env('SUPABASE_ANON_KEY');
  const secrets = parseKeySet('SUPABASE_SECRET_KEYS');
  const serviceKey = secrets.default || env('SUPABASE_SERVICE_ROLE_KEY');
  if (!url || !anonKey || !serviceKey) return json({ error: 'Supabase function secrets are not configured.' }, 503);

  const auth = req.headers.get('authorization') || '';
  const tokenMatch = auth.match(/^Bearer\s+(.+)$/i);
  if (!tokenMatch) return json({ error: 'Sign in to use ALFRED cloud features.' }, 401);
  const authClient = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: userResult, error: authError } = await authClient.auth.getUser(tokenMatch[1]);
  if (authError || !userResult.user) return json({ error: 'Your session has expired. Sign in again.' }, 401);
  const userId = userResult.user.id;
  const db = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });

  let body: any;
  try {
    const raw = await req.text();
    if (raw.length > 1_000_000) return json({ error: 'Request is too large.' }, 413);
    body = JSON.parse(raw);
  } catch { return json({ error: 'Request must be valid JSON.' }, 400); }
  const action = body?.action || 'chat';

  if (action === 'memory_list') {
    const { data, error } = await db.from('alfred_memories').select('id,memory_text,created_at')
      .eq('user_id', userId).order('created_at', { ascending: false }).limit(50);
    if (error) return json({ error: 'Could not load memory.' }, 500);
    return json({ memories: data ?? [] });
  }
  if (action === 'memory_clear') {
    const memories = await db.from('alfred_memories').delete().eq('user_id', userId);
    const conversations = await db.from('alfred_conversations').delete().eq('user_id', userId);
    if (memories.error || conversations.error) return json({ error: 'Could not clear cloud history and memory.' }, 500);
    return json({ ok: true });
  }

  const contents = Array.isArray(body?.contents) ? body.contents.slice(-12) : [];
  const sys = typeof body?.systemInstruction === 'string' ? body.systemInstruction.slice(0, 3000) : '';
  const promptText = userText(contents);
  if (!contents.length || !promptText) return json({ error: 'A text request is required.' }, 400);
  const isRemember = body?.remember === true;
  const shouldRecall = /\b(remember|memory|what do you know about me|what have i told you)\b/i.test(promptText);

  let context = '';
  if (shouldRecall) {
    const { data } = await db.from('alfred_memories').select('memory_text')
      .eq('user_id', userId).order('created_at', { ascending: false }).limit(25);
    if (data?.length) context = data.map((x: any) => `- ${x.memory_text}`).join('\n');
  }
  if (isRemember) {
    const fact = promptText.replace(/^\s*(please\s+)?(remember|save to memory|don't forget)\s*(that)?\s*/i, '').trim();
    if (fact && fact.length <= 500) {
      const { error } = await db.from('alfred_memories').insert({ user_id: userId, memory_text: fact });
      if (error) return json({ error: 'I could not save that memory.' }, 500);
      context = [context, `- ${fact}`].filter(Boolean).join('\n');
    }
  }

  let contentsForModel = [...contents];
  // On a new device/browser, restore recent text-only conversation turns from the signed-in account.
  if (contents.filter((x: any) => x?.role === 'user').length === 1) {
    const { data: previous } = await db.from('alfred_conversations').select('user_text,assistant_text')
      .eq('user_id', userId).order('created_at', { ascending: false }).limit(6);
    if (previous?.length) contentsForModel = [...previous.reverse().flatMap((x: any) => [
      { role: 'user', parts: [{ text: x.user_text }] }, { role: 'model', parts: [{ text: x.assistant_text }] },
    ]), ...contentsForModel];
  }
  const systemInstruction = [sys, 'You are ALFRED, an accessible assistant. Give useful, direct answers. If information may have changed, say so or use available web search grounding. Use personal memory only when relevant. Never claim ALFRED guarantees safe navigation.',
    context ? `The user explicitly saved these personal memories. Use only when relevant; do not invent facts:\n${context}` : 'No explicit personal memories have been saved.'].filter(Boolean).join('\n\n');

  if (isRemember) {
    const reply = 'I’ll remember that.';
    const { error } = await db.from('alfred_conversations').insert({ user_id: userId, user_text: promptText, assistant_text: reply });
    if (error) return json({ error: 'I saved the fact, but could not save the conversation.' }, 503);
    return json({ text: reply, remembered: true });
  }

  const { data: allowed, error: quotaError } = await db.rpc('alfred_take_daily_quota', { p_user_id: userId, p_limit: 120 });
  if (quotaError) return json({ error: 'Usage control is unavailable. Check that the ALFRED database migration is applied.' }, 503);
  if (allowed !== true) return json({ error: 'Daily ALFRED cloud limit reached for this account. Try again tomorrow or sign out and use your personal key in local mode.' }, 429);

  const serverKeys = env('GEMINI_API_KEYS').split(/[\n,;]+/).map(x => x.trim()).filter(Boolean);
  const keys = [...new Set([...serverKeys, ...uniqueKeys(body?.apiKeys)])];
  if (!keys.length) return json({ error: 'Add a Gemini key in Settings or configure GEMINI_API_KEYS in Supabase.' }, 400);
  const model = typeof body?.model === 'string' && /^gemini-[a-z0-9.-]{1,80}$/.test(body.model)
    ? body.model : 'gemini-3.5-flash-lite';
  let answer = '';
  let sources: Array<{ title: string; url: string }> = [];
  let lastError = 'Gemini did not return a response.';
  for (const key of keys) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 25000);
    try {
      const payload: any = { contents: contentsForModel, systemInstruction: { parts: [{ text: systemInstruction }] } };
      if (body?.googleSearch === true) payload.tools = [{ google_search: {} }];
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
        method: 'POST', signal: controller.signal,
        headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
        body: JSON.stringify(payload),
      });
      const data = await response.json().catch(() => ({}));
      const generated = textFromGemini(data);
      if (response.ok && generated) { answer = generated; sources = sourcesFromGemini(data); break; }
      const providerMessage = String(data?.error?.message || `Gemini returned HTTP ${response.status}`).slice(0, 220);
      lastError = providerMessage;
      // Rotate exhausted/revoked keys, but do not hide model, request, or billing errors as quota failures.
      if (![401, 403, 429].includes(response.status) && data?.error?.status !== 'RESOURCE_EXHAUSTED') break;
    } catch (e) {
      lastError = e instanceof Error && e.name === 'AbortError' ? 'Gemini timed out.' : 'Could not reach Gemini.';
      break;
    } finally { clearTimeout(timeout); }
  }
  if (!answer) return json({ error: lastError }, 502);

  const cleanAnswer = answer.slice(0, 8000);
  const { error: saveError } = await db.from('alfred_conversations').insert({
    user_id: userId, user_text: promptText, assistant_text: cleanAnswer,
  });
  if (saveError) return json({ error: 'The answer was generated, but cloud memory could not save it. Check that the ALFRED database migration is applied.' }, 503);
  // Keep recent context for cross-device continuity without retaining an unbounded transcript.
  await db.from('alfred_conversations').delete().eq('user_id', userId)
    .lt('created_at', new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString());
  return json({ text: cleanAnswer, remembered: isRemember, sources });
});
