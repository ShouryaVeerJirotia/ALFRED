# ALFRED status (2026-11-08)

## Implemented in the current sketch

- Responsive single-page dashboard served by ESP32-CAM.
- Camera snapshot/vision request, sensor telemetry, voice input/output, and phone-action intents.
- Wi-Fi saved-network recovery access point and web provisioning.
- Browser-side user Gemini keys and rotation logic.
- Confirmation flow for call/SMS intents.
- Dedicated scene description, read-visible-text, and find-in-frame controls; visual requests fail instead of silently asking Gemini without a camera frame.
- Voice diagnostics distinguish microphone active, recognized speech, no-speech, unsupported language, and missing permission. While the mic is on, ordinary speech is accepted without a wake word; “Alfred” is optional.
- Current-information prompts can invoke Google Search grounding by default for a new browser profile; the user can turn it off. Direct browser Gemini responses can display verified HTTPS source links.
- A local desktop companion proxies the device UI from `localhost` and sends confirmed code requests to Codex CLI in an isolated copy of the selected Git project. The patch requires a separate apply click; the ESP32 exposes no command endpoint. This flow is implemented in source but has not yet been exercised end-to-end.

The previous revision, including the bilingual voice selector and safer API-key persistence default, was uploaded through CP2102 and passed flash-hash verification on 2026-11-07. The newer natural-voice, search, source-link, vision, and Codex UI changes compiled successfully for AI Thinker ESP32-CAM with ESP32 Arduino core 3.3.10. The compiled source is now copied to `/Users/raviraijirotia/Documents/Arduino/AlfredsFirmware_v2.2/AlfredsFirmware_v2.2.ino`; its SHA-256 matches the compiled project source. It has not been flashed. No Arduino/CP2102 board is currently connected.

The current Git checkout has no remote configured, and the connected GitHub integration cannot access the private ALFRED repository. These latest local changes have not been published.

During the owner's Chrome check, the dashboard activity log contained recognized speech transcripts, but the old firmware stayed in standby and ignored phrases without “Alfred” or an orb tap. The browser page also reported the ESP32 device offline. The new code accepts any recognized phrase while the user-controlled mic is active. This remains unverified on hardware until the new sketch is flashed and a voice request gets an answer.

## Added in this project

- A versioned project copy, original local firmware backup, and Android source. The original backup is intentionally excluded from GitHub; its redacted review copy is available under `backups/`.
- A unique per-board recovery AP password and `alfred.local` mDNS alias when the network supports it.
- A Supabase account UI, user-specific cloud chat history, explicitly saved facts, clear-memory action, and daily request limit in the Edge Function source.
- Supabase project `ALFRED-Showcase` deployed in Mumbai with the memory tables/quota migration and `alfred-assistant` Edge Function.
- Firmware dashboard prefilled with the project's public URL and publishable key; users can sign in across devices and use cloud memory.
- Shared Gemini key pool stored as the `GEMINI_API_KEYS` Supabase Edge Function secret for server-side rotation.
- Hindi, English (India), and automatic Hindi/English input/output selection in the web dashboard and Android speech bridge; actual speech recognition and Hindi TTS vary by device and need hands-on verification.
- The local Edge Function source now extracts verified HTTPS source links from Gemini grounding metadata. It has not yet been redeployed; the deployed function currently returns answer text without the source list.
- Desktop companion source is in `desktop/alfred_desktop.py`. It binds to loopback only, requires a private IP or `.local` ALFRED address plus a Git project path, filters secret-named files from the isolated snapshot, runs Codex CLI with a workspace-write sandbox, and exposes a patch for explicit review/application.

## Not yet implemented or verified

Barcode/QR reader, trusted-contact SOS/location share, persistent reminders, phone-to-computer pairing and general desktop control, universal testing across browser/device families, the first verified signed-in cloud chat/memory session, desktop bridge end-to-end validation, and hardware sensor validation.

Google Search grounding is enabled by default for current-information prompts in a new browser profile. Previously saved opt-outs remain off. Google's current Gemini API pricing page lists Search grounding as unavailable on the Free tier; an eligible paid-tier project may be required. Confirm model support, account quota and any usage charges before a public demonstration.

The function accepts personal Gemini keys from the signed-in browser over HTTPS as a fallback. The public Supabase publishable key in the firmware is designed for client use; it is not an admin secret. The Gemini keys are stored only in Supabase project secrets.

No feature should be described as working end-to-end until its checklist is completed. This prototype is not a navigation replacement.
