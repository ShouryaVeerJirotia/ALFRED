# ALFRED verification checklist

## Firmware build and flash

- [x] Compile with AI Thinker ESP32-CAM target and ESP32 Arduino core 3.3.10.
- [x] Flash latest bilingual voice/key-storage revision through CP2102; flash hash verification passed.
- [ ] Flash the newer local natural-voice/vision/search/Codex-UI revision; build succeeds, but it is not on the device yet.
- [ ] Confirm normal boot logs, camera startup and dashboard availability. The current Chrome page reports the device offline; the owner's latest battery/sensor test has not produced a verified status response yet.
- [ ] Test power cycling, lost router, wrong password, setup AP and successful new Wi-Fi save.

## Browser/device support

- [ ] Android Chrome; iPhone/iPad Safari; Windows Chrome/Edge; macOS Safari/Chrome.
- [ ] Responsive layout, screen reader labels, keyboard operation, camera fetch and sensor data.
- [ ] Typed request and TTS on every target; microphone recognition only where target browser supports it.
- [x] Current Chrome dashboard activity log showed recognized speech transcripts on the old revision; the revised flow now accepts speech with no wake phrase while mic mode is on, but it still needs a hardware answer test.
- [x] Hindi, English (India), and automatic Hindi/English selector added; speech-service behavior remains device-dependent and unverified.
- [ ] Android wrapper bridge actions and runtime permissions.

## Product functions

- [x] Supabase memory/quota migration and `alfred-assistant` Edge Function deployed; `GEMINI_API_KEYS` configured as a Supabase secret.
- [ ] Signed-in Gemini chat, automatic Google Search grounding for current-information prompts, cloud source links after function redeploy, image description and key rotation for an exhausted key.
- [ ] Check current model support, account quota and charges for Search grounding before a public demonstration.
- [ ] OCR/read-aloud and object-finding actions: controls and prompts are implemented locally; camera and result quality are not verified.
- [ ] Invalid key/model/network errors are shown accurately and do not loop.
- [ ] Supabase sign-up/sign-in, session refresh, cross-device chat history, explicit memory, review and delete.
- [ ] Always-on voice limits, English/Hindi wake phrase, language selection and device-by-device behavior.
- [ ] Reminder creation, persistence, notification delivery, quiet hours and cancellation.
- [ ] Run the desktop companion against a test Git project; verify localhost audio input, isolated Codex edits, secret-file exclusions, patch preview, apply, discard and stale-patch rejection.
- [ ] Verify same-computer-only access, Codex authentication failure, device offline and companion shutdown behavior; phone-to-PC pairing remains a separate future feature.
- [ ] Phone action intents: call/SMS always require confirmation; test music/navigation links.
- [ ] Camera absent, sensor absent/stale and no-network states remain understandable.

## Physical and accessibility validation

- [ ] Stable power under camera/Wi-Fi load; camera ribbon secure; no brownout/reboot.
- [ ] HC-SR04 Echo voltage divided to 3.3 V; check boot-strapping-pin effects on GPIO12/15.
- [ ] Sensor measurements compared to known references; flame sensor tested only as a hobby sensor.
- [ ] Blind/low-vision user review of setup, voice feedback, screen reader flow, errors and confirmations.
- [ ] Clearly state that ALFRED is supplementary and cannot guarantee safe navigation.
